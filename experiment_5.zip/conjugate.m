
clear;

% Ax = b

A = [ 1, 1/2; 1/2, 1/3];

b = [5/21 ; 11/84];

% Initial x1 and x2 values

x = [ 1; 1];

v = [ 0; 0];

for i=1:20

    r(:,i) = b - A*x(:,i);
    v(:,i+1) = r(:,i);
    
    tk(i) = v(:,i+1)'*r(:,i) / (v(:,i+1)' * A*v(:,i+1));
    x(:,i+1)= x(:,i) + v(:,i+1)*tk(i);
    
end




