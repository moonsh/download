
clear;

% case 1.
% f=@(x) x-2.^(-x);

% case 2.
% f=@(x) exp(-x) .* (3.2 .* sin(x) - 0.5 .*cos(x)) ;

 f=@(x)  (x-3).^2 -4;


% Input
a(1)=0; b(1)=4;       % End points a,b
grat = (sqrt(5)-1)/2;
tol= 10^-3;           % Tolerance
step_number=100;       % Maximum number of iterations
stop=0;               % Final iteration


   d = grat*(b(1)-a(1));
     x2(1) = a(1)+d;   %d = 0.6180
     x1(1) = b(1)-d;

 for i=1:step_number
              
         if f(x1(i))>f(x2(i))
             a(i+1) = x1(i);
             b(i+1) = b(i);
             d = grat * ( b(i+1)-a(i+1));
             x1(i+1) = b(i+1)-d;
             x2(i+1) = a(i+1)+d;
                            
         else
             a(i+1) = a(i);
             b(i+1) = x2(i);
             d = grat * ( b(i+1)-a(i+1));
             x1(i+1) = b(i+1)-d;
             x2(i+1) = a(i+1)+d;
              
 
         end
         
         if (b(i)-a(i)) < tol
             break;
         end
 end

  t = a(1):0.01:b(1);
  subplot(1,2,1)
  plot(t,f(t));
  title('Function figure')
  xlabel('x')
  ylabel('F(x)')
  grid on;
  
 subplot(1,2,2)
 plot(x1,f(x1),'ro');
 title('Function figure')
 xlabel('x')
 ylabel('F(x)')
 grid on;

  
  
  
