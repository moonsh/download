
clear;

% case 1.
% f=@(x) x-2.^(-x);

% case 2.
% f=@(x) exp(-x) .* (3.2 .* sin(x) - 0.5 .*cos(x)) ;

 f=@(x)  (x-3).^2 +x -4;


% Input
a(1)=0; b(1)=2; c(1)=4;      % End points a,c
tol= 10^-3;           % Tolerance
step_number=100;       % Maximum number of iterations
stop=0;               % Final iteration

 for i=1:step_number
              
     deno(i) = (b(i)-a(i))*(f(b(i))-f(c(i)))-(b(i)-c(i))*(f(b(i))-(f(a(i))));
     numer(i) = (b(i)-a(i))^2*(f(b(i))-f(c(i)))-(b(i)-c(i))^2*(f(b(i))-(f(a(i))));
     
     if(deno==0)
         break;
     end
     
     x(i)= b(i) -  numer(i)/deno(i)/2;  
          
         if f(x(i))<f(b(i)) && x(i) < b(i) 
             a(i+1)=a(i);
             b(i+1)=x(i);
             c(i+1)=b(i);
                 
         elseif f(x(i))<f(b(i)) && x(i) > b(i) 
            
             a(i+1)=b(i);
             b(i+1)=x(i);
             c(i+1)=c(i);

          elseif f(x(i))>f(b(i)) && x(i) < b(i) 
            
              a(i+1)=x(i);
              b(i+1)=b(i);
              c(i+1)=c(i);
              
             
          elseif f(x(i))>f(b(i)) && x(i) > b(i) 
             
              a(i+1)=a(i);
              b(i+1)=b(i);
              c(i+1)=x(i);
             
         end
         
         if f(x(i))== f(b(i))
             break;
         end
         
 end

  t = a(1):0.01:c(1);
  subplot(1,2,1)
  plot(t,f(t));
  title('Function figure')
  xlabel('x')
  ylabel('F(x)')
  grid on;
  
  subplot(1,2,2)
  plot(x,f(x),'ro');
  title('Function figure')
  xlabel('x')
  ylabel('F(x)')
  grid on;

  
  
  
