VectorXf v;
v.setConstant(3, 5);
cout << v << endl;
