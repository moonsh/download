Matrix4i m = Matrix4i::Random();
m.row(1).setZero();
cout << m << endl;
