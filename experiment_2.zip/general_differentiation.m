
clear;

x_data= [ 0, 1, 2, 3];
y_data= [ 2, 2, 3, 2];

n=length(x_data);
step=(x_data(n)-x_data(1))/1000;            
x=(x_data(1):step:x_data(n));

L=ones(n,length(x));     

for k=1:n             
    for i=1:n  
       if (k~=i)     
           L(k,:)=L(k,:).*((x-x_data(i))/(x_data(k)-x_data(i)));
       end
       
    end
end

y=0;        
for k=1:n
   
    f=y_data(k).*L(k,:);  
    y=y+f;
  
end

plot(x,y)            
hold on
plot(x_data,y_data,'or')
xlabel('x');
ylabel('y');
title('Plot using Lagrange Polynomial Interpolation')


% Three point end point  formula

x_data= [ 1, 2, 3];
y_data= [ 2, 3, 2];

h = x_data(2)-x_data(1);

result1 = (-3*y_data(1) + 4*y_data(2) - y_data(3))/(2*h) ;

 fprintf('Three point end point = %f  \n', result1);

% Three point mid point formula
    
x_data= [ 0, 1, 2];
y_data= [ 2, 2, 3];

result2 = (y_data(3) - y_data(1))/(2*h);

 fprintf('Three point mid point = %f \n' , result2);


