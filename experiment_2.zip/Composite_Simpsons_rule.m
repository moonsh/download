
% Example function: y = x^5;

clear; 

 f=@(x)  x.^5 ;

interval = 6;

x_data=[1 3 ]; 

h = (x_data(2) - x_data(1))/interval;

for i=1:(interval+1)
   
    x(i)= x_data(1) + h*(i-1);
    
end
 
alpha = 0;
for i =1:(interval/2-1)
    
    alpha =  alpha + f(x(2*i+1));
    
end

beta = 0;
for i =1:(interval/2)
    
    beta = beta + f(x(2*i));
    
end

result = (f(x_data(1)) + 2* alpha + 4* beta + f(x_data(2)) )*h/3;

 fprintf('Result = %f  \n', result);
