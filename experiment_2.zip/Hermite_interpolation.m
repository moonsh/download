
clear;

x_data=[-2.000, -1, 2, 3];  
y_data=[-1.000, -0.151, 1, 2];  
yd_data=[ 0, 0, -2, 0];

n=length(x_data);
step=(x_data(n)-x_data(1))/1000;           

x=(x_data(1):step:x_data(n));

   L= ones(n,length(x));          % Lagrange  polynomials
   a=zeros(n,length(x));         
   b=zeros(n,length(x));           
   H=zeros(1,length(x));         % Hermie interpolation polynomial 
   d1_L= zeros(n,length(x));         

   for i=1:n       
       d_L=0;             % derivative of Lagrange basis
       for j=1:n    
           if j~=i
               d_L=d_L+1/(x_data(i)-x_data(j));
               L(i,:)=L(i,:).*(x-x_data(j))/(x_data(i)-x_data(j)); 
           end
       end
       d1_L = L(i,:) * d_L;
       L_2=L(i,:).^2;
       a(i,:)=(1-2*(x-x_data(i)).*d1_L).*L_2;  
       b(i,:)=(x-x_data(i)).*L_2;           
       H=H+a(i,:)*y_data(i)+b(i,:)*yd_data(i);  % Hermite polynomial H(x)
   end   
   
plot(x_data,y_data,'or')      
hold on
plot(x,H);
xlabel('x');
ylabel('y');
title('Plot using Hermite Interpolation')


