clear; 

x_data=[1 2 3 4 5 6]; 
y_data=[3 8 7 3 3 6]; 

n=length(x_data); 

for i=1:n
    
    a(i) = y_data(i);
    
end

for i=1:(n-1)
    
   h(i) = x_data(i+1) - x_data(i);
   
end

for i=2:(n-1)

    alpha(i) = 3/h(i)*(a(i+1) - a(i) ) - 3/h(i-1)*(a(i)- a(i-1));
    
end

l(1) = 1;
u(1) = 0;
z(1) = 0;

for i=2:(n-1)
 
    l(i) = 2*(x_data(i))- h(i-1) * u(i-1);
    u(i) = h(i)/l(i);
    z(i) = (alpha(i) - h(i-1)*z(i-1))/l(i);
      
end
l(n) = 1;
z(n) = 0;
c(n) = 0;

for j=(n-1):-1:1
    c(j) = z(j)- u(j)*c(j+1);
    b(j) = (a(j+1) - a(j))/h(j) - h(j)*(c(j+1) + 2* c(j))/3;
    d(j) = (c(j+1) - c(j)) / (3* h(j));
  
end

for i=1:(n-1)
    
   x=[x_data(i):0.001:x_data(i+1)]; 
   y=a(i) + b(i)*(x- x_data(i)) + c(i)* (x-x_data(i)).^2 + d(i)*(x-x_data(i)).^3;
   plot(x,y);
   hold on;

end
plot(x_data,y_data,'ro') ;
xlabel('x');
ylabel('y');
title('Plot using Natural Cubic Spline')



