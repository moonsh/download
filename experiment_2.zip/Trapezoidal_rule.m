
% Example function: y = x^5;

clear; 

 f=@(x)  x.^5 ;

x_data=[1 3 ]; 

h = x_data(2) - x_data(1);

result = h*(f(x_data(2))+f(x_data(1)))/2;

fprintf('Result = %f  \n', result);
