
clear;

f = @(t) t.^4;
df = @(t) 4*t.^3;

x_data = [ 2 ];

h = 0.013;

h1 = 0.01:0.001:0.02;
exact = df(x_data);

forward_df = (f(x_data+h) - f(x_data) ) / h;

for i=1:length(h1)
 forward_df1(i) = (f(x_data+h1(i)) - f(x_data) ) / h1(i);
 backward_df1(i) = (f(x_data+h1(i)) - f(x_data) ) / h1(i);
end

h = h * -1;
backward_df = (f(x_data+h) - f(x_data) ) / h;


fprintf(' Forward-difference %f , Backward-difference %f \n', forward_df, backward_df);
fprintf(' Exact %f  \n',  exact);

plot(h1, backward_df1);

 xlabel('h')
 ylabel('f`(x)')

