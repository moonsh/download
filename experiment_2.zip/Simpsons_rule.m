
% Example function: y = x^5;

clear; 

 f=@(x)  x.^5;
 
x_data=[1 3 ]; 

h = (x_data(2) - x_data(1))/2;

n=length(x_data); 

x(1) = x_data(1);
x(2) = x_data(1) + h;
x(3) = x_data(2);

result = h* (f(x(1))+4*f(x(2)) + f(x(3))) /3;

fprintf('Result = %f  \n', result);
